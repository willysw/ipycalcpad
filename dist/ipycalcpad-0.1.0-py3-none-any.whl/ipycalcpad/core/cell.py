from typing import Sequence

from .line import Line

from ..display import Display

class Cell:
    lines: Sequence[Line] = []

    def __init__(self, *,
                 lines: Sequence[Line] = None):
        self.lines = lines if lines is not None else []

    def render_md(self) -> str:
        disp = Display()
        line_text = (disp.render_md(line) for line in self.lines)
        return "\n\n".join(line_text)

    def __str__(self):
        out = ['Cell:']
        for i, line in enumerate(self.lines):
            if line.expression:
                out.append(f'{i:3d}: {line.expression!s}')
            elif line.comment:
                out.append(f'{i:3d}: {line.comment}')
        return "\n".join(out)

    def __repr__(self):
        return self.__str__()
    
    def _repr_markdown_(self):
        print(self.__str__()) #DEBUG
        return self.render_md()
