import math
from typing import Mapping

from ..atoms import Atom


class Line:
    namespace:Mapping = None
    expression:Atom = None
    long_print:bool = False
    comment:str = None

    def __init__(self,
                 namespace:Mapping = None,
                 expr:Atom = None,
                 long_print:bool = False,
                 comment:str = None):
        self.namespace = namespace
        self.expression = expr
        self.long_print = long_print
        self.comment = comment

    @property
    def value(self) -> float|int:
        return self.expression.value if self.expression else None
    
    @property
    def result(self) -> str|None:
        if self.expression:
            val = self.expression.value
            if not math.isnan(val):
                if isinstance(val, int):
                    return f'{val:d}'
                else:
                    return f'{val:.4f}'
            else:
                return None
        else:
            return None
    
    @property
    def text(self) -> str|None:
        return f'{self.expression.text}' if self.expression else None

    @property
    def latex(self) -> str|None:
        return f'{self.expression.latex}' if self.expression else None

    @property
    def latex_substituted(self) -> str|None:
        if self.expression:
            substituted, changed = self.expression.substitute_vars() 
            if changed:
                try:
                    return f'{substituted.latex}'
                except Exception as err:
                    print(err) #DEBUG
        
        return None
    