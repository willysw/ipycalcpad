from jinja2 import Environment, PackageLoader

from .. import Line

class Display:
    _instance: 'Display' = None

    def render_md(self, line: Line) -> str:
        out = self._line_md_template.render(line=line)
        print(f'Rendered MD:\n {out}\n') #DEBUG
        return out

    #FILTERS
    @staticmethod
    def _comment(line:Line, *args, **kwargs) -> str:
        return f'{line.comment}: ' if line.comment else ""
        
    #CONSTRUCTION
    def __init__(self):
        self._env = Environment(
            block_start_string = r'\BLOCK{',
            block_end_string = r'}',
            variable_start_string = r'\VAR{',
            variable_end_string = r'}',
            comment_start_string = r'\#{',
            comment_end_string = r'}',
            line_statement_prefix = r'%%',
            line_comment_prefix = r'%#',
            trim_blocks = True,
            lstrip_blocks=True,
            keep_trailing_newline=False,
            autoescape = False,
            loader=PackageLoader('calcpad')
        )
        # Register filters
        self._env.filters['comment'] = self._comment

        # Load templates
        self._line_md_template = self._env.get_template('line.md.jinja')

    def __new__(cls, *args, **kwargs):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
