from typing import Tuple

from .atom import Atom
from .terminal import Var


class Assign(Atom):
    def __init__(self, var:Var, expr:Atom):
        self.var, self.expr = var, expr

    @property
    def value(self):
        return self.expr.value
    
    @property
    def text(self):
        return f'{self.var.text} = {self.expr.text}'
    
    @property
    def latex(self):
        return f'{self.var.latex} = {self.expr.latex}'
    
    def substitute_vars(self) -> Tuple[Atom, bool]:
        substituted, changed = self.expr.substitute_vars()
        return (substituted, changed)

    def __str__(self):
        return f'Assign({self.var!s}, {self.expr!s})'
