import math
from typing import Sequence, Tuple

from .atom import Atom

class UnaryOp(Atom):
    right: Atom
    text_template: str
    latex_template: str
    right_parens: Sequence[str]

    def __init__(self, right:Atom):
        self.right = right

    @staticmethod
    def operation(right): return math.nan

    @property
    def value(self):
        return self.operation(self.right.value)
    
    @property
    def text(self):
        return self.text_template.format(
            right=self.text_parens(self.right, self.right_parens))

    @property
    def latex(self):
        return self.latex_template.format(
            right=self.latex_parens(self.right, self.right_parens))

    def substitute_vars(self) -> Tuple[Atom, bool]:
        cls = self.__class__
        subs_right, changed = self.right.substitute_vars() 
        return (cls(right=subs_right), changed)

class Neg(UnaryOp):
    text_template = '-{right}'
    latex_template = '-{{{right}}}'
    right_parens = ['Add', 'Sub']

    @staticmethod
    def operation(right): return -right
