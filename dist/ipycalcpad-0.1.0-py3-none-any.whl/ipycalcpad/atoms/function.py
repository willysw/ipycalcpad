import math
from typing import Callable, Sequence, Tuple

from .atom import Atom

class Func(Atom):
    def __init__(self,
                 *,
                 name:str,
                 function:Callable,
                 arguments:Sequence[Atom]):
        self.function_name = name
        self.function = function
        self.arguments = arguments

    @property
    def value(self):
        if self.function and isinstance(self.function, Callable):
            return self.function(*[arg.value for arg in self.arguments])
        else:
            return math.nan

    @property
    def text(self):
        args_text = ', '.join([arg.text for arg in self.arguments])
        return f'{self.function_name}({args_text})'

    @property
    def latex(self):
        args_latex = ',\\;'.join([f'{{{arg.latex}}}' for arg in self.arguments])
        return f'\\textrm{{{self.function_name}}}\\left({{{args_latex}}}\\right)'

    def substitute_vars(self) -> Tuple[Atom, bool]:
        cls = self.__class__
        substituted = []
        changed = False
        for arg in self.arguments:
            sub_arg, arg_changed = arg.substitute_vars()
            substituted.append(sub_arg)
            changed = changed or arg_changed
        return (
            cls(name=self.function_name,
                function=self.function,
                arguments=substituted),
            changed)
        
    def __str__(self):
        return (
            'Func(' +
            ', '.join([str(arg) for arg in self.arguments]) +
            ')'
        )