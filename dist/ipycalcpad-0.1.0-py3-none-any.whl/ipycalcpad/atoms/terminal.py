import math
from typing import Tuple

from .atom import Atom


class Number(Atom):
    def __init__(self, value: float|int):
        self._value = value

    @property
    def value(self): return self._value

    @property
    def text(self):
        return Atom.format_number(self._value)
        
    @property
    def latex(self):
        return Atom.format_number(self._value)
    
    def substitute_vars(self) -> Tuple[Atom, bool]:
        return (Number(self.value), False)


class Var(Atom):
    def __init__(self, var:str, number:Number|int|float = None):
        self.var = var
        if isinstance(number, (int, float)):
            self.number = Number(number)
        elif isinstance(number, Number):
            self.number = number
        else:
            self.number = Number(math.nan)  

    @property
    def value(self): return self.number.value
    
    @property
    def text(self):
        return self.var
    
    @property
    def latex(self):
        script, _, subscript = self.var.partition('_')
        if subscript:
            return f'{script}_{{{subscript}}}'
        else:
            return f'{script}'
        
    def substitute_vars(self) -> Tuple[Atom, bool]:
        if not math.isnan(self.value):
            return (Number(self.value), True)
        return (Var(self.var, self.value), False)