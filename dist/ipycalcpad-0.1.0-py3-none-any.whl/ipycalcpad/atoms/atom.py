from abc import ABC, abstractmethod
from typing import Sequence, Tuple


class Atom(ABC):

    @property
    @abstractmethod
    def value(self) -> float: pass

    @property
    @abstractmethod
    def text(self) -> str: pass

    @property
    @abstractmethod
    def latex(self) -> str: pass

    @abstractmethod
    def substitute_vars(self) -> Tuple['Atom', bool]: pass

    def __str__(self):
        clsname = self.__class__.__name__
        if hasattr(self, 'left') and hasattr(self, 'right'):
            return f'{clsname}[{str(self.left)}, {str(self.right)}]'
        else:
            return clsname

    @staticmethod
    def text_parens(atom:Atom, close_atoms:Sequence[str]) -> str:
        if close_atoms and atom.__class__.__name__ in close_atoms:
            return f'({atom.text})'
        else:
            return atom.text

    @staticmethod
    def latex_parens(atom:Atom, close_atoms:Sequence[str]) -> str:
        if close_atoms and atom.__class__.__name__ in close_atoms:
            return f'\\left({atom.latex}\\right)'
        else:
            return atom.latex
        
    @staticmethod
    def format_number(value: float|int) -> str:
        if isinstance(value, int):
            return f'{value:d}'
        else:
            return f'{value}'
