"""
========== BINARY OPERATORS ========== 
The following classes represent binary operators. They all inherit
from BinaryOp, which provides common functionality for handling 
operator formatting.
"""
from abc import abstractmethod
import math
from typing import Sequence, Tuple


from .atom import Atom
from .terminal import Number


class BinaryOp(Atom):
    left: Atom
    right: Atom
    text_template: str
    latex_template: str
    left_parens: Sequence[str]
    right_parens: Sequence[str]

    def __init__(self, left:Atom, right:Atom):
        self.left = left
        self.right = right

    @staticmethod
    @abstractmethod
    def operation(left, right): return math.nan

    @property
    def value(self):
        return self.operation(self.left.value,
                              self.right.value)
    
    @property
    def text(self):
        return self.text_template.format(
            left=self.text_parens(self.left, self.left_parens),
            right= self.text_parens(self.right, self.right_parens))

    @property
    def latex(self):
        return self.latex_template.format(
            left=self.latex_parens(self.left, self.left_parens),
            right=self.latex_parens(self.right, self.right_parens))

    def substitute_vars(self) -> Tuple[Atom, bool]:
        cls = self.__class__
        sub_left, changed_left = self.left.substitute_vars()
        sub_right, changed_right = self.right.substitute_vars()
        changed = changed_left or changed_right
        return (cls(left=sub_left, right=sub_right), changed)
    

class Add(BinaryOp):
    text_template = '{left}+{right}'
    latex_template = '{{{left}}}+{{{right}}}'
    left_parens = []
    right_parens = []

    @staticmethod
    def operation(left, right): return left + right


class Sub(BinaryOp):
    text_template = '{left}-{right}'
    latex_template = '{{{left}}}-{{{right}}}'
    left_parens = []
    right_parens = ['Add', 'Sub']
    
    @staticmethod
    def operation(left, right): return left - right


class Mul(BinaryOp):
    text_template = '{left}*{right}'
    latex_template = '{{{left}}}{sep}{{{right}}}'
    left_parens = []
    right_parens = []
    
    @staticmethod
    def operation(left, right): return left * right

    @property
    def latex(self):
        return self.latex_template.format(
            left=self.latex_parens(self.left, self.left_parens), 
            right=self.latex_parens(self.right, self.right_parens), 
            sep='\\cdot' if isinstance(self.right, Number) else '\\,')
    

class Div(BinaryOp):
    text_template = '{left}/{right}'
    latex_template = '\\dfrac{{{left}}}{{{right}}}'
    left_parens = ['Add', 'Sub']
    right_parens = ['Add', 'Sub', 'Mul', 'Div'] 

    @staticmethod
    def operation(left, right): return left / right

    @property
    def latex(self):
        return self.latex_template.format(
            left=self.latex_parens(self.left, ['Div']), 
            right=self.latex_parens(self.right, ['Div']))


class Pow(BinaryOp):
    text_template = '{left}^{right}'
    latex_template = '{{{left}}}^{{{right}}}'
    left_parens = ['Add', 'Sub', 'Mul', 'Div']
    right_parens = []

    @staticmethod
    def operation(left, right): return left ** right
