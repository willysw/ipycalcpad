import math
from typing import Mapping
from lark import Transformer

from ..core.line import Line
from ..atoms import (
    Atom, Number, Var, Func, Assign,
    Add, Sub, Mul, Div, Pow, Neg,
)

class _LONG_PRINT: pass


class _COMMENT:
    comment:str = None
    def __init__(self, comment:str): self.comment = comment


class CellTransformer(Transformer):
    namespace: Mapping = None

    def __init__(self, *args,
                 namespace:Mapping = None,
                 **kwargs):
        self.namespace = namespace if namespace else dict()
        super().__init__(*args, **kwargs)
    
    def cell(self, args):
        return [arg for arg in args if isinstance(arg, Line)]
    
    def line(self, args):
        expr, long_print, comment = None, False, None
        for arg in args:
            if isinstance(arg, Atom):
                expr = arg

            if isinstance(arg, _LONG_PRINT):
                long_print = True

            if isinstance(arg, _COMMENT):
                comment = arg.comment
        
        return Line(namespace=self.namespace,
                    expr=expr,
                    long_print=long_print,
                    comment=comment)

    def long_print(self, args):
        return _LONG_PRINT()

    def comment(self, args):
        return _COMMENT(args[0].value[2:].strip())

    # Terminals

    def SIGNED_INT(self, args): return Number(int(args))
    def SIGNED_FLOAT(self, args): return Number(float(args))
    def CNAME(self, args): return str(args)

    # Expressions

    def mul(self, args): return Mul(args[0], args[1])
    def div(self, args): return Div(args[0], args[1])
    def add(self, args): return Add(args[0], args[1])
    def sub(self, args): return Sub(args[0], args[1])
    def pow(self, args): return Pow(args[0], args[1])
    def neg(self, args): return Neg(args[0])

    def var(self, args):
        return Var(
            var=args[0],
            number=self.namespace.get(args[0], math.nan))
            
    def func(self, args):
        function_name, *arguments = args
        return Func(
            name=function_name,
            function=self.namespace.get(function_name),
            arguments=arguments
            )
    
    def assign(self, args):
        var_name, expr = args

        subs_expr, _ = expr.substitute_vars()
        expr_value = subs_expr.value
        if not math.isnan(expr_value):
            self.namespace.update({var_name: expr_value})
        
        return Assign(var=Var(var=var_name),
                      expr=expr)

    def expr(self, args):
        return args[0]
    