from lark import Lark

class Parser:
    _parser:Lark = None

    def __init__(self):
        self._parser = Lark.open_from_package(
                __name__,
                'syntax.lark'
                )

    @classmethod
    def __new__(cls, *args, **kwargs):
        if cls._parser is None:
            cls._parser = super().__new__(cls)
        return cls._parser

    def parse(self, *args, **kwargs):
         return self._parser.parse(*args, **kwargs)