from .parser import Parser
from .celltransformer import CellTransformer

from ..core.cell import Cell

from IPython.core.magic import (
    Magics,
    magics_class,
    line_magic,
    cell_magic,
    needs_local_scope,
)
from IPython.display import display

from lark import Tree

@magics_class
class Magic(Magics):

    @needs_local_scope
    @cell_magic
    def calcpad(self, line='', cell=None, local_ns=None):
        tree:Tree = Parser().parse(cell)
        lines = CellTransformer(namespace=local_ns).transform(tree)
        return Cell(lines=lines)
    
    